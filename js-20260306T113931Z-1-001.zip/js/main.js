document.addEventListener("DOMContentLoaded", () => {

    const burger = document.getElementById("burger");
    const menu = document.getElementById("menu");
    const links = document.querySelectorAll("#menu a");

    // ------------------------------
    // MENU HAMBURGUESA
    // ------------------------------

    burger.addEventListener("click", () => {
        burger.classList.toggle("active");
        menu.classList.toggle("active");

        const expanded = burger.getAttribute("aria-expanded") === "true";
        burger.setAttribute("aria-expanded", !expanded);
    });

    // Cerrar al clickear link
    links.forEach(link => {
        link.addEventListener("click", () => {
            menu.classList.remove("active");
            burger.classList.remove("active");
            burger.setAttribute("aria-expanded", "false");
        });
    });

    // ------------------------------
    // REVEAL (Animaciones)
    // ------------------------------

    const observerOptions = {
        threshold: 0.15,
        rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const elementsToReveal = document.querySelectorAll('.reveal, .hero-content, .service-card');
    elementsToReveal.forEach(el => observer.observe(el));


    // ------------------------------
    // LÓGICA DE SELECCIÓN DE HORA (CHIPS)
    // ------------------------------
    const chips = document.querySelectorAll('.chip');
    const horaInput = document.getElementById('hora-input');

    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            // 1. Quitar activo de todos
            chips.forEach(c => c.classList.remove('active'));
            // 2. Activar el clickeado
            chip.classList.add('active');
            // 3. Guardar valor en el input oculto
            if(horaInput) {
                horaInput.value = chip.getAttribute('data-value');
            }
        });
    });


    // ------------------------------
    // LÓGICA ENVÍO A WHATSAPP + CARTEL
    // ------------------------------
    const formReservas = document.getElementById('form-reservas');
    const overlay = document.getElementById('reservaOverlay');

    if (formReservas) {
        formReservas.addEventListener('submit', function(e) {
            e.preventDefault(); // EVITA QUE SE RECARGUE LA PÁGINA

            // 1. Validar que haya hora seleccionada
            if (!horaInput.value) {
                alert("Por favor, selecciona un horario.");
                return;
            }

            // 2. Capturar datos
            const nombre = document.getElementById('nombre-reserva').value;
            const fecha = document.getElementById('fecha').value;
            const personas = document.getElementById('personas').value;
            const hora = horaInput.value;

            // 3. Mostrar el cartel de "Gracias"
            if (overlay) {
                overlay.classList.add('active');
            }

            // 4. Preparar el mensaje de WhatsApp
            // REEMPLAZA ESTE NÚMERO CON EL TUYO (código país + area + numero, sin espacios ni +)
            // Ejemplo Argentina: 5491112345678
            const telefonoRestaurante = "5491100000000"; 
            
            const texto = `Hola Garci, quiero reservar una mesa.%0A%0A📅 Fecha: ${fecha}%0A⏰ Hora: ${hora}%0A👥 Personas: ${personas}%0A👤 Nombre: ${nombre}`;
            
            const urlWhatsapp = `https://wa.me/${telefonoRestaurante}?text=${texto}`;

            // 5. Redirigir después de 2 segundos (para que vean el cartel)
            setTimeout(() => {
                window.location.href = urlWhatsapp;
                
                // Opcional: Ocultar cartel y limpiar formulario si vuelven atrás
                if (overlay) overlay.classList.remove('active');
                formReservas.reset();
                chips.forEach(c => c.classList.remove('active'));
            }, 2500);
        });
    }

});